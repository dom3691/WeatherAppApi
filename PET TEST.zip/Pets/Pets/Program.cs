﻿using System;


using static System.Console;
namespace Pets
{
    public class Program
    {
        static void Main(string[] args)
        {

            PetWorld petWorld= new PetWorld();
            petWorld.Run();

        }
    }
}
